const db = require('../config/db')

exports.homePageGetController = (req,res,next) =>{
    res.render("pages/home")
}

exports.aboutPageGetController = (req,res,next) =>{
    res.render("pages/about")
}