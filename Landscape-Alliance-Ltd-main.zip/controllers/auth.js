exports.signUpGetController = (req,res,next) =>{
    res.send("i am from sign up")
}
exports.logoutGetController = (req,res,next) =>{
    res.send("i am from logout")
}
