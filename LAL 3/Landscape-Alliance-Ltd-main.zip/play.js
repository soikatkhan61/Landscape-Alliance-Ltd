const path = require('path')
const src = "http://localhost:3000/upload/projects/post-1661493790636.jpg"

console.log(path.basename(src))
