module.exports = error =>error.msg
